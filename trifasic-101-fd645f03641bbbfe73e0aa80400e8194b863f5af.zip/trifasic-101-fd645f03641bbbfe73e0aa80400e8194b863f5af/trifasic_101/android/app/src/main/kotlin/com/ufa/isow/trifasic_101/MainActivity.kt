package com.ufa.isow.trifasic_101

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
