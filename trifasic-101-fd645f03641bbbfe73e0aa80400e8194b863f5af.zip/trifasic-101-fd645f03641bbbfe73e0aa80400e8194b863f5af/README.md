# trifasic-101
App móvil de ejemplo NRC1073
